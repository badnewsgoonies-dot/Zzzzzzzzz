/*
 * Test setup file
 * Imports @testing-library/jest-dom matchers for Vitest
 */

import '@testing-library/jest-dom/vitest';

