export const VERSION = '7.5.0';
